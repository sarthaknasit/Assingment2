package com.library.bodyboost;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import android.os.Bundle;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

public class WorkoutActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_workout);

        displayWorkoutDetails();
    }

    private void displayWorkoutDetails() {

        String workoutName = "Push-ups";
        int sets = 3;
        int reps = 10;
        int duration = 30;
        TextView workoutNameTextView = findViewById(R.id.workoutNameTextView);
        TextView setsRepsTextView = findViewById(R.id.setsRepsTextView);
        TextView durationTextView = findViewById(R.id.durationTextView);

        workoutNameTextView.setText(workoutName);
        setsRepsTextView.setText("Sets: " + sets + " Reps: " + reps);
        durationTextView.setText("Duration: " + duration + " seconds");
    }
}

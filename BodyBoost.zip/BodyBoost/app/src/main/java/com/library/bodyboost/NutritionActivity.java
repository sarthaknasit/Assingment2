package com.library.bodyboost;

import android.os.Bundle;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

public class NutritionActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_nutrition);

        displayNutritionDetails();
    }

    private void displayNutritionDetails() {
        String foodName = "Apple";
        double calories = 52;
        double protein = 0.3;
        double carbs = 13.8;
        double fats = 0.2;

        TextView foodNameTextView = findViewById(R.id.foodNameTextView);
        TextView caloriesTextView = findViewById(R.id.caloriesTextView);
        TextView proteinTextView = findViewById(R.id.proteinTextView);
        TextView carbsTextView = findViewById(R.id.carbsTextView);
        TextView fatsTextView = findViewById(R.id.fatsTextView);

        foodNameTextView.setText(foodName);
        caloriesTextView.setText("Calories: " + calories);
        proteinTextView.setText("Protein: " + protein + "g");
        carbsTextView.setText("Carbs: " + carbs + "g");
        fatsTextView.setText("Fats: " + fats + "g");
    }
}

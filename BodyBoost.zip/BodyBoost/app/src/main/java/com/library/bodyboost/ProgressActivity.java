package com.library.bodyboost;

import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import com.github.mikephil.charting.charts.LineChart;
import com.github.mikephil.charting.data.Entry;
import com.github.mikephil.charting.data.LineData;
import com.github.mikephil.charting.data.LineDataSet;

import java.util.ArrayList;
import java.util.List;

public class ProgressActivity extends AppCompatActivity {

    private LineChart weightChart;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_progress);

        weightChart = findViewById(R.id.weight_chart);
        setupWeightChart();
    }

    private void setupWeightChart() {
        List<Entry> entries = new ArrayList<>();
        entries.add(new Entry(0, 75.2f));
        entries.add(new Entry(1, 74.8f));
        entries.add(new Entry(2, 74.1f));
        entries.add(new Entry(3, 73.5f));
        entries.add(new Entry(4, 72.9f));

        LineDataSet dataSet = new LineDataSet(entries, "Weight (kg)");
        LineData lineData = new LineData(dataSet);
        weightChart.setData(lineData);
        weightChart.invalidate();
    }
}
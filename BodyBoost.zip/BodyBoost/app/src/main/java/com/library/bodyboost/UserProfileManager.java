package com.library.bodyboost;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.FirebaseFirestore;

import java.util.HashMap;
import java.util.Map;

public class UserProfileManager {
    private FirebaseFirestore mFirestore;
    private FirebaseAuth mAuth;

    public UserProfileManager() {
        mFirestore = FirebaseFirestore.getInstance();
        mAuth = FirebaseAuth.getInstance();
    }

    public void createUserProfile(String username, String email) {
        FirebaseUser user = mAuth.getCurrentUser();
        if (user != null) {
            DocumentReference profileRef = mFirestore.collection("users").document(user.getUid());
            Map<String, Object> userProfile = new HashMap<>();
            userProfile.put("username", username);
            userProfile.put("email", email);
            profileRef.set(userProfile);
        }
    }
}

package com.library.bodyboost;

import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import java.util.ArrayList;
import java.util.List;

public class CommunityActivity extends AppCompatActivity {

    private RecyclerView recyclerView;
    private CommunityAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_community);

        // Initialize RecyclerView
        recyclerView = findViewById(R.id.recyclerView);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        adapter = new CommunityAdapter();
        recyclerView.setAdapter(adapter);

        // Example: Load community posts
        loadCommunityPosts();
    }

    private void loadCommunityPosts() {
        // Example: Fetch community posts from database or other source
        List<CommunityPost> posts = new ArrayList<>();
        posts.add(new CommunityPost("User1", "Great workout today! 💪 #fitness"));
        posts.add(new CommunityPost("User2", "Just finished my morning run. Feeling energized! 🏃‍♂️"));
        // Add more posts as needed

        // Update RecyclerView with posts
        adapter.setPosts(posts);
        adapter.notifyDataSetChanged();
    }
}

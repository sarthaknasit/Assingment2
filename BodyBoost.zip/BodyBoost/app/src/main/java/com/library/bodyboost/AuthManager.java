package com.library.bodyboost;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;

public class AuthManager {
    private FirebaseAuth mAuth;

    public AuthManager() {
        mAuth = FirebaseAuth.getInstance();
    }

    public void registerUser(String email, String password, OnAuthResultListener listener) {
        mAuth.createUserWithEmailAndPassword(email, password)
                .addOnCompleteListener(task -> {
                    if (task.isSuccessful()) {
                        listener.onSuccess("Registration successful");
                    } else {
                        listener.onFailure("Registration failed: " + task.getException().getMessage());
                    }
                });
    }

    public void loginUser(String email, String password, OnAuthResultListener listener) {
        mAuth.signInWithEmailAndPassword(email, password)
                .addOnCompleteListener(task -> {
                    if (task.isSuccessful()) {
                        listener.onSuccess("Login successful");
                    } else {
                        listener.onFailure("Login failed: " + task.getException().getMessage());
                    }
                });
    }

    public interface OnAuthResultListener {
        void onSuccess(String message);
        void onFailure(String errorMessage);
    }
}

package com.library.bodyboost;

import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import java.util.ArrayList;
import java.util.List;

public class AchievementsActivity extends AppCompatActivity {

    private RecyclerView recyclerView;
    private AchievementsAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_achievements);

        recyclerView = findViewById(R.id.recyclerView);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        adapter = new AchievementsAdapter();
        recyclerView.setAdapter(adapter);

        loadAchievementsData();
    }

    private void loadAchievementsData() {

        List<Achievement> achievements = new ArrayList<>();
        achievements.add(new Achievement("First Workout", "Complete your first workout", true));
        achievements.add(new Achievement("10K Steps", "Walk 10,000 steps in a day", false));

        adapter.setAchievements(achievements);
        adapter.notifyDataSetChanged();
    }
}
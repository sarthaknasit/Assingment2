package com.library.bodyboost;

import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class WorkoutPlannerActivity extends AppCompatActivity {

    private Spinner workoutTypeSpinner;
    private EditText durationEditText;
    private Button addWorkoutButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_workout_planner);

        workoutTypeSpinner = findViewById(R.id.workoutTypeSpinner);
        durationEditText = findViewById(R.id.durationEditText);
        addWorkoutButton = findViewById(R.id.addWorkoutButton);

        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this,
                R.array.workout_types, android.R.layout.simple_spinner_item);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        workoutTypeSpinner.setAdapter(adapter);

        addWorkoutButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                addWorkout();
            }
        });
    }

    private void addWorkout() {
        String workoutType = workoutTypeSpinner.getSelectedItem().toString();
        String duration = durationEditText.getText().toString();

        if (duration.isEmpty()) {
            Toast.makeText(this, "Please enter duration", Toast.LENGTH_SHORT).show();
            return;
        }

        Toast.makeText(this, "Added " + duration + " minutes of " + workoutType + " workout", Toast.LENGTH_SHORT).show();

        durationEditText.getText().clear();
    }
}
package com.library.bodyboost;

import android.os.Bundle;
import android.view.View;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import java.util.Random;

public class MotivationActivity extends AppCompatActivity {

    private TextView motivationTextView;
    private String[] motivations;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_motivation);

        motivationTextView = findViewById(R.id.motivationTextView);
        motivations = getResources().getStringArray(R.array.motivations);

        displayRandomMotivation();
    }

    public void onRefreshClick(View view) {
        displayRandomMotivation();
    }

    private void displayRandomMotivation() {
        Random random = new Random();
        int index = random.nextInt(motivations.length);
        String motivation = motivations[index];
        motivationTextView.setText(motivation);
    }
}
